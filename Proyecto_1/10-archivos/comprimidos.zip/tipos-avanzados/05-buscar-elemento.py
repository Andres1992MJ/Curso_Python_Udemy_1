mascotas= ["Loki", "Shaky", "Gordo", "Nessme", "Sasha","Nessme"]


print(mascotas.count("Nessme"))

if "Nessme" in mascotas:
    print(mascotas.index("Nessme"))




