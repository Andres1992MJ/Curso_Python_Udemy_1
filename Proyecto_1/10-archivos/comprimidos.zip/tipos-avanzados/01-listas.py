numeros =[1,2,3,4,5]                           #[1,2,3,4,5]

letras = ["a","b","c","d","e"]                 #["a","b","c","d","e"] 

palabras = ["Correr", "Estudiar", "Programar"] #['Correr', 'Estudiar', 'Programar']

matriz=[[0,1],["Hola", "Mundo"]]               #[[0, 1], ['Hola', 'Mundo']]

ceros =[0] * 10                                #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

alfanumerico= numeros+ palabras                #[1, 2, 3, 4, 5, 'Correr', 'Estudiar', 'Programar']

rango=list(range(50, 81))                       #[50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]

char= list("Andres Medina")                    #['A', 'n', 'd', 'r', 'e', 's', ' ', 'M', 'e', 'd', 'i', 'n', 'a']

print(char)



