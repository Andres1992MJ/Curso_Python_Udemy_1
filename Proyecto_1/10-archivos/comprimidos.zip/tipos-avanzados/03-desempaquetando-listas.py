numeros = range(1,21)

primero, segundo, tercero, *otros, ultimo =numeros

print(primero)
print(segundo)
print(tercero)
print(otros)
print(ultimo)