from usuario import guardar,pagar_impuestos


guardar()

pagar_impuestos()