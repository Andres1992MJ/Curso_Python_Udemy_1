def guardar():
    print("Guardadndo")

def pagar_impuestos():
    print("Pagando impuestos")