from usuarios.impuestos.utilidades import pagar_impuestos




pagar_impuestos()