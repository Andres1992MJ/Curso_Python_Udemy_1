from usuarios.utilidades.acciones import guardar,pagar_impuestos     #<--------ACA FUE EL CAMBIO

#from usuarios import acciones ---- es otra forma correcta de importar pero al llamar la funcion
#Se debe llamar de la manera acciones.guardar() o acciones.pagar_impuestos()


guardar()

pagar_impuestos()