def suma( a,b):
    resultado = a + b
    return resultado

valor_total= 0

valor_total = suma(5,5) + suma(3,7)
print( valor_total)