def hola(nombre="", apellido=""):
    print(f"""hola mundo {nombre} {apellido}""")


hola("Andres", "Medina")

hola(apellido="Medina", nombre="Andres")

