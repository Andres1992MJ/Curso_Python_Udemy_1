def suma (a, b):
    resultado = a + b
    return resultado


result1 = suma(55, 25)
result2 = suma(result1, 25)
print(result2)