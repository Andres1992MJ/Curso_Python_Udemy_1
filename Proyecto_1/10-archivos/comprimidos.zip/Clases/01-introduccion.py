mensaje = "Hola mundo"

print(type(mensaje)) #<class 'str'>


#Clase: Es un modelo para construir objetos.
#Objeto: es una instancia de una clase.


#Clases:plano de una casa
#Objeto: la casa contruida

#Clase: Humano
#Objeto: Andres, Daniela, Carolina

