def init():
    print("Este es el modulo uno")