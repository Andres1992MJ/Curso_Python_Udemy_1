try:
    n1=int(input("Ingresa un numero:"))
except:
    print("Error, debes ingresar un numero")