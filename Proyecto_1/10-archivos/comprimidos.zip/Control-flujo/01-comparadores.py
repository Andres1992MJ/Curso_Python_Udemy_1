print( 1 > 2)    #False
print( 1 < 2)    #true
print( 1 <= 2)   #True
print( 1 >= 2)   #False
print( 2 >= 2)   #True
print( 1 == 2)   #False
print( 2 == 2)   #True
print( "2" == 2) #False
print( "2" != 2) #True
print( 2 != 2)   #False



