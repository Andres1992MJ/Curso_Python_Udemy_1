edad = 15

# if edad > 17:
#     mensaje = "Es Mayor"
# else:
#     mensaje = "Es Menor"

# print(mensaje)



mensaje = "Es Mayorr" if edad > 17 else "es muy menor"

print(mensaje)