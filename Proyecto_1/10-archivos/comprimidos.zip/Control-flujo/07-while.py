# # numero = 5
# # while numero <=100:
# #     print(numero)
# #     numero *=2


# comando = ""

# while comando.lower()!= "salir":
#     comando = input("$ ")
#     print(comando)


while True:
    comando = input("$ ")
    print(comando)
    if comando.lower() == "salir":
        break
    
