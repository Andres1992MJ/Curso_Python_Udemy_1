"""Introduccion a Python."""

print("Hola mundo!")
print("Andres " * 5)
