#Comentario
# \" escribe comillas en un string
# \' comilla sencilla
# \ \ pone el slash
# \n salto de linea


curso="Ultimate \n\"Python\""

print(curso)