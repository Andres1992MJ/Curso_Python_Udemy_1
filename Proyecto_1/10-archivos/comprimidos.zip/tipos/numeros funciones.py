import math


print(round(1.3)) # Reddondea hacia mayotr o menor mas cercano
print(round(1.7))
print(round(1.5))
print(abs(-77)) # entrega el valor pòsitivo
print(abs(55))

print(math.ceil(1.1)) #superior entero mas cercano
print(math.floor(1.99991)) #Numero entero cercano abajo
print(math.isnan(23)) #EL valor correspondiente no es un numero
print(math.pow(10, 3)) # Elevar a la potencia
print(math.sqrt(9)) # Raiz Cuadrada