

nombre_curso = "Ultimate Python!!!!!!"
nombre1 = "Andres Medina"
print(nombre_curso)
print(nombre1)
print(nombre_curso,nombre1)

alumnos = 5000 #int
puntaje = 9.3 #float
publicado =  True #bool
nombre2 = "Este es un texto" #string
