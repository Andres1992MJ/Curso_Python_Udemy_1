nombre_curso= "Python Completo"

descripcion_curso= """
este curso contempla todos los detalles que necesitas aprender
para encontrar
trabajo como programandor"""

print(descripcion_curso)

print(len(nombre_curso)) #imprime cuantos caracteres tiene el string
print(nombre_curso[0])  #imprime el valor asignado en el incice 0 del string 
print(nombre_curso[1])  #imprime el valor asignado en el incice 1 del string 
print(nombre_curso[2])  #imprime el valor asignado en el incice 2 del string 
print(nombre_curso[3])  #imprime el valor asignado en el incice 3 del string 
print(nombre_curso[4])  #imprime el valor asignado en el incice 4 del string 
print(nombre_curso[5])  #imprime el valor asignado en el incice 5 del string 

print(nombre_curso[0:6]) #imprime desde el indice 0 hasta la posicion indicada

print(nombre_curso[7:15]) #imprime desde el indice 0 hasta la posicion indicada



