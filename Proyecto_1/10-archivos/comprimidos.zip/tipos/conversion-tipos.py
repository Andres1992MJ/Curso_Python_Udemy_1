x =input("")


#int()
#str()
#float
#bool


print(bool(""))   #False
print(bool("0"))  #True
print(bool(None)) #False
print(bool(" "))  #True
print(bool(0))    #False
