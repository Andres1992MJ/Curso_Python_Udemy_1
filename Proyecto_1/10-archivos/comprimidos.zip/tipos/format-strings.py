
nombre= "Andres"

apellido = "Medina"

nombre_completo = nombre + apellido

print ( nombre_completo)

nombre_completo_1= f"{nombre} {apellido}"

print ( nombre_completo_1)

nombre_completo_2= f"{nombre[1]} {4*3}"

print ( nombre_completo_2)
