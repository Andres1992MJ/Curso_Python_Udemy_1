numero = 2 # Entreo-> integer
decimal = 1.2 #float
imaginario= 2+2j #2 + 2i imaginario es la raiz de -1


#Operaciones

print (1+3) #Suma
print (1-3)  # Resta
print (1*3) # Multiplica
print (1/3) # Divide
print (1//3) # Divide pero solo entrega el numero entero
print (8%3) # Sobrante
print (8**3) #Elevado

numero += 5

print(numero)
