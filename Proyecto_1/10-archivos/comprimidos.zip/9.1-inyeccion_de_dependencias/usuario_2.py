def guardar():
    print("Guardadndo desde usuario 2")